setwd("C:\\Users\\LENOVO\\OneDrive\\Desktop\\it24103408_Ps_lab-08")

data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
Weight <- as.numeric(data$Weight.kg.)

pop_mean <- mean(Weight)
pop_sd   <- sd(Weight) 

pop_mean
pop_sd

set.seed(123)
num_samples <- 25
sample_size <- 6

sample_means <- replicate(num_samples, mean(sample(Weight, sample_size, replace = TRUE)))
sample_sds   <- replicate(num_samples, sd(sample(Weight, sample_size, replace = TRUE)))

sample_means
sample_sds

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means   <- sd(sample_means)

mean_of_sample_means
sd_of_sample_means

theoretical_se <- pop_sd / sqrt(sample_size)
theoretical_se
