setwd("C:\\Users\\LENOVO\\OneDrive\\Desktop\\it24103408_Ps-Lab_09")

#1 random sample of size 25
baking_times <- rnorm(25, mean = 45, sd = 2)

#2 Test whether the average baking time is less than 46 minutes at a 5% level of significance.
test_result <- t.test(baking_times, mu = 46, alternative = "less")

print(test_result)

